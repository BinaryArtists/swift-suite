# vapor-multipart-formdata-sample
Sample server side app for multipart/form-data file upload

# Usage 
```
$ vapor build
$ vapor run serve
```

# development environment
- macOS Sierra 10.12.3
- Xcode 8.2.1
- Homebrew 1.1.1
- swiftenv 1.2.1
- Swift Snapshot DEVELOPMENT-SNAPSHOT-2017-03-09-a
- Vapor Toolbox 1.0.5
